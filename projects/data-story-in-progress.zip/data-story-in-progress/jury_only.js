let juryW = d3.select(".map-visualization-wrapper").style("width").split("px").shift();
let juryH = 500;
let juryXpadding = 100;
let juryYpadding = 50;
let juryPadding = 50;
let graphHeight = juryH-juryPadding*2;
// let formatYear = d3.timeParse("%Y");
// let continents = ["Africa", "Anglo America", "Asia", "Europe", "Latin America", "Oceania"]

let juryViz = d3.select(".jury-only-visualization-wrapper")
          .append("svg")
          .style("width", juryW)
          .style("height", juryH)
          .style("background-color", "#323232")
;

d3.json("data/continent-country.json").then(function(continentData){
  d3.json("data/venice_jury.json").then(function(incomingData){
    console.log(incomingData);
    incomingData = incomingData.map(d=>{
      d.year = formatYear(d.year)
      return d;
    })
    console.log(incomingData);
  //
    incomingData = incomingData.map(function(data){
      let correspondingDatapoint = continentData.find(function(things){
          // console.log(data);
          if(things.country == data.nationality){
            return true
          } else {
            return false
          }
        })
      // console.log(correspondingDatapoint);
      // console.log(correspondingDatapoint.continent);
      data.continent = correspondingDatapoint.continent
      return data
    })
  // })
    // console.log(incomingData);
  //
  //
    // x scale & AXIS
    let extent = d3.extent(incomingData, d=>d.year);
    let xScale = d3.scaleTime().domain(extent).range([juryXpadding, juryW-juryXpadding]);
    let xAxis = d3.axisBottom(xScale);
    let xAxisGroup = juryViz.append("g")
                          .attr("class", "xaxisgroup")
                          .attr("transform", "translate("+(juryXpadding/2)+","+(juryH-juryYpadding)+")")
    ;
    xAxisGroup.call(xAxis);
  //
    //y scale & axis
    let continentScale = d3.scaleBand().domain(continents).range([juryYpadding, juryH-juryYpadding]);
    // console.log("Europe: " continentScale("Europe"));
    // console.log("Europe: " continentScale("Europe"));
    let continentAxis = d3.axisLeft(continentScale);
    let continentAxisGroup = juryViz.append("g")
                                  .attr("class", "continentaxisgroup")
                                  .attr("transform", "translate("+(juryXpadding)+",0)")
    ;
    continentAxisGroup.call(continentAxis);
    // console.log(continentScale.bandwidth());

    let graphGroup = juryViz.append("g").attr("class", "graphgroup")

    let individualDataGroup = graphGroup.selectAll(".individualData").data(incomingData).enter()
                                              .append("g")
                                              .sort((a,b)=>{
                                                return d3.ascending(a.guessed_gender, b.guessed_gender)
                                              })
                                              .attr("class", "individualData")
    ;
  //
    individualDataGroup.append("circle")
                        .attr("class", "datapoint")
                        .attr("r", 5)
                        .attr("fill", function(d,i){
                          if (d.guessed_gender == "male"){
                            return "DodgerBlue"
                          } else {
                            return "deeppink"
                          }
                        })
                        // .attr("stroke", "black")
                        // .attr("stroke-width", 1)
    ;
    incomingData = incomingData.map(function(datapoint){
      datapoint.x = xScale(datapoint.year)+xpadding/2;
      datapoint.y = continentScale(datapoint.continent)+continentScale.bandwidth()/2;
      return datapoint
    })
  //
  //   console.log(incomingData.length);
    let simulation = d3.forceSimulation(incomingData)
                        .force("forceX", d3.forceX(function(d){
                          return xScale(d.year)+xpadding/2
                        }))
                        .force("forceY", d3.forceY(function(d){
                          return continentScale(d.continent)+continentScale.bandwidth()/2
                        }))
                        .force("collide", d3.forceCollide(6))
                        .on("tick", simulationRan)
    ;
    function simulationRan(){
      // console.log(incomingData[0]);
      graphGroup.selectAll(".individualData")
                  .attr("transform", function(d){
                    let x = d.x
                    let y = d.y
                    return "translate("+ x +","+ y +")"
                  })
      ;
    }
  //
  })
})
